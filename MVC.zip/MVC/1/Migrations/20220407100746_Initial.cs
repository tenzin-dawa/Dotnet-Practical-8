﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _1.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Student_Teacher_TeacherTID",
                table: "Student");

            migrationBuilder.DropIndex(
                name: "IX_Student_TeacherTID",
                table: "Student");

            migrationBuilder.DropColumn(
                name: "TeacherTID",
                table: "Student");

            migrationBuilder.CreateIndex(
                name: "IX_Student_TID",
                table: "Student",
                column: "TID");

            migrationBuilder.AddForeignKey(
                name: "FK_Student_Teacher_TID",
                table: "Student",
                column: "TID",
                principalTable: "Teacher",
                principalColumn: "TID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Student_Teacher_TID",
                table: "Student");

            migrationBuilder.DropIndex(
                name: "IX_Student_TID",
                table: "Student");

            migrationBuilder.AddColumn<int>(
                name: "TeacherTID",
                table: "Student",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Student_TeacherTID",
                table: "Student",
                column: "TeacherTID");

            migrationBuilder.AddForeignKey(
                name: "FK_Student_Teacher_TeacherTID",
                table: "Student",
                column: "TeacherTID",
                principalTable: "Teacher",
                principalColumn: "TID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
